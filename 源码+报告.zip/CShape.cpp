﻿// CShape.cpp: 实现文件
//

#include "pch.h"
#include "DrawApp.h"
#include "CShape.h"


// CShape
//实现序列化
IMPLEMENT_SERIAL(CShape,CObject,1)
CShape::CShape()
{
	m_shapType = 0;
	m_centrePoint = 0;
	m_ptOrign = 0;
	m_ptDestination = 0;
	m_lineStyle = 0;
	m_pointSize = 0;
	m_lineWidth = 0;
	m_lineColor = RGB(0, 0, 0);
	m_fillColor = RGB(255, 255, 255);
	//m_isSelected = 0;
}

CShape::~CShape()
{
}







// CShape 成员函数


void CShape::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
		ar << m_pointSize << m_lineStyle << m_lineWidth 
			<< m_lineColor << m_fillColor << m_shapType 
			<< m_centrePoint << m_ptOrign << m_ptDestination;
	}
	else
	{	// loading code
		ar >> m_pointSize >> m_lineStyle >> m_lineWidth 
			>> m_lineColor >> m_fillColor >> m_shapType 
			>> m_centrePoint >> m_ptOrign >> m_ptDestination;
	}
	Serialize(ar);
}
void CShape::SetFillColor(COLORREF fillColor) {
	m_fillColor = fillColor;
}
void CShape::SetLineColor(COLORREF lineColor){
	m_lineColor = lineColor;
}
void CShape::SetLineStyle(int lineStyle){
	m_lineStyle = lineStyle;
}
void CShape::SetLineWidth(int lineWidth) {
	m_lineWidth = lineWidth;

}
void CShape::SetPointSize(int pointSize) {
	m_pointSize = pointSize;
}

CShape::CShape(int shapeTYpe, CPoint centrePoint, int pointSize){
	m_shapType = shapeTYpe;
	m_centrePoint = centrePoint;
	m_pointSize = pointSize;

	
}//点

//直线、圆、椭圆、正方形
CShape::CShape(int shapeTYpe, CPoint ptOrigin, CPoint ptDestination) {
	m_shapType = shapeTYpe;
	m_ptOrign = ptOrigin;
	m_ptDestination = ptDestination;

}
CShape::CShape(int shapeTYpe, CPoint ptOrigin, CPoint ptDestination, int lineStyle, int lineWidth, COLORREF lineColor, COLORREF fillColor) {
	m_shapType = shapeTYpe;
	m_ptOrign = ptOrigin;
	m_ptDestination = ptDestination;
	m_lineStyle = lineStyle;
	m_lineWidth = lineWidth;
	m_lineColor = lineColor;
	m_fillColor = fillColor;
}
CShape::CShape(int shapeTYpe, int lineStyle, int lineWidth, COLORREF lineColor, COLORREF fillColor) {
	m_shapType = shapeTYpe;
	m_lineStyle = lineStyle;
	m_lineWidth = lineWidth;
	m_lineColor = lineColor;
	m_fillColor = fillColor;
}

void CShape::Draw(CDC* pDC) {
	//这三句报错
	//尝试引用已删除的函数
	//在报错的地方类型声明前加&符号
	CPen& newPen = CPen(m_lineStyle, m_lineWidth, m_lineColor);
	CPen* oldPen = pDC->SelectObject(&newPen);
	CBrush& newBrush=CBrush(m_fillColor);
	int n = m_pointArry.GetSize();
	pDC->SelectObject(&newBrush);//使用画笔
	switch (m_shapType)
	{case INVALID :
	break;
	case DF_POINT :
		pDC->Ellipse(m_centrePoint.x - m_pointSize, m_centrePoint.y - m_pointSize, m_centrePoint.x + m_pointSize, m_centrePoint.y + m_pointSize);
		break;
	case DF_LINE:
		pDC->MoveTo(m_ptOrign);
		pDC->LineTo(m_ptDestination);
		break;
	case DF_POLYLINBE:
	case DF_MULTLINE:
		
		if (n <= 0) {
			return;
		}
		else{
		pDC->MoveTo(m_pointArry[0]);
		for (int i = 1; i < n; i++)
		{
			pDC->LineTo(m_pointArry[i]);
		}
		}
		break;
	case DF_CIRCLE:
	{	//画正方形小公式
		int offset = int((m_ptDestination.y - m_ptOrign.y) - (m_ptDestination.x - m_ptOrign.x)) / 2;
		m_ptDestination.x += offset;
		m_ptDestination.y -= offset;
		pDC->Ellipse(m_ptOrign.x, m_ptOrign.y, m_ptDestination.x, m_ptDestination.y);
	break;
	}
	case SQ:
	{	//画正方形小公式
		int offset = int((m_ptDestination.y - m_ptOrign.y) - (m_ptDestination.x - m_ptOrign.x)) / 2;
		m_ptDestination.x += offset;
		m_ptDestination.y -= offset;
		pDC->Rectangle(m_ptOrign.x, m_ptOrign.y, m_ptDestination.x, m_ptDestination.y);
		break; }
	case ELLY:
		pDC->Ellipse(m_ptOrign.x, m_ptOrign.y, m_ptDestination.x, m_ptDestination.y);
		break;
	case DF_POLYGON:
		break;
	
	default:
		break;
	}
}
//移动
void CShape::MOVEGraph(int xoffset, int yoffset) {
	switch (m_shapType)
	{
	case 0:
		break;
	case 1:
		m_centrePoint.x = m_centrePoint.x + xoffset;
		m_centrePoint.y = m_centrePoint.y + yoffset;

	case 2:
	case 5:
	case 6:
	case 7:
		m_ptOrign.x = m_ptOrign.x + xoffset;
		m_ptOrign.y = m_ptOrign.y + yoffset;
		m_ptDestination.x= m_ptDestination.x + xoffset;
		m_ptDestination.y = m_ptDestination.y + yoffset;
		break;
	case 3:
	case 4:
		for (int i = 0; i < m_pointArry.GetSize(); i++) {
			m_pointArry.GetAt(i).x += xoffset;
			m_pointArry.GetAt(i).y += yoffset;
		}
		break;
	default:
		break;
	}
}
//修改大小
void CShape::Resize(float factor) {
	int width = m_ptDestination.x - m_ptOrign.x;
	int heigth = m_ptDestination.y - m_ptOrign.y;
	int xIncrement = (width * factor - width) / 2;
	int yIncrement = (heigth * factor - heigth) / 2;
	/*int xIncrement = factor / 2;
	int yIncrement = factor / 2;*/
	switch (m_shapType)
	{
	case 0:
		break;
	case 1:
		m_pointSize = int(m_pointSize * factor);
		break;
	case 2:
	case 5:
	case 6:
	case 7:
		
		if (m_ptOrign.y > m_ptDestination.y) {
			m_ptOrign.x -= xIncrement;
			m_ptOrign.y += yIncrement;
			m_ptDestination.x += xIncrement;
			m_ptDestination.y -= yIncrement;
		}
		else {
			m_ptOrign.x -= xIncrement;
			m_ptOrign.y -= yIncrement;
			m_ptDestination.x += xIncrement;
			m_ptDestination.y += yIncrement;
		}
		break;
	case 3:
	case 4:
		//折线和随手画扩大
		break;
	default:
		break;
	}

}
//int shapeTYpe, int lineStyle, int lineWidth, COLORREF lineColor, COLORREF fillColor
CShape::CShape(CShape* other, int lineWidth, COLORREF lineColor, COLORREF fillColor)
{

	//this->m_pointSize = other->m_pointSize;
	this->m_lineWidth = lineWidth;
	this->m_lineStyle = other->m_lineStyle;
	//this->m_lineColor = other->m_lineColor;
	//this->m_fillColor = other->m_fillColor;
	this->m_lineColor = lineColor;
	this->m_fillColor = fillColor;
	this->m_isSelected = other->m_isSelected;
	this->m_shapType = other->m_shapType;
	for (int i = 0; i < other->m_pointArry.GetSize(); i++)
	{
		
		this->m_pointArry.Add(other->m_pointArry.GetAt(i));
	}
}