﻿#pragma once
//#include <afxwin.h>
//#include <afx.h>
// 
// 
//定义0-7状态
// 0无效，1 点, 2 直线, 3 折线, 4随手画, 5 圆, 6 正方形, 7 椭圆
#define INVALID 0
#define DF_POINT 1
#define DF_LINE 2
#define DF_POLYLINBE 3
#define DF_MULTLINE 4
#define DF_CIRCLE 5
#define SQ 6
#define ELLY 7
#define DF_POLYGON 8

// CShape 命令目标
class CShape : public CObject
{
	DECLARE_SERIAL(CShape)
public:
	CShape();
	virtual ~CShape();
private:
	//int m_shapType=0;//0无效，1 点,2 直线,3 折线,4随手画,5 圆,6 正方形,7 椭圆
	
	//折线 随手画 一系列的点、线
	//CTypedPtrArray<基类类型，参数类型>
	
private:
	//绘图属性
	int m_pointSize=3;
	int m_lineStyle=0;
	int m_lineWidth=3;
	COLORREF m_lineColor= RGB(0, 0, 0);
	COLORREF m_fillColor= RGB(255, 255, 255);
	
public:

	BOOL m_isSelected;//是否被选中
	CPoint m_centrePoint;//中心点
	CPoint m_ptOrign, m_ptDestination;//起点和终点

	void SetFillColor(COLORREF fillColor);
	void SetLineColor(COLORREF lineColor);
	void SetLineStyle(int lineStyle);
	void SetLineWidth(int lineWidth);
	void SetPointSize(int pointSize);
	CArray<CPoint,CPoint&> m_pointArry;//存储折线  DF_POLYLINBE  DF_MULTLINE
	int m_shapType = 0;//0无效，1 点,2 直线,3 折线,4随手画,5 圆,6 正方形,7 椭圆
public:
	CShape(int shapeTYpe, CPoint centrePoint, int pointSize);//点
	CShape(CShape* other, int lineWidth, COLORREF lineColor, COLORREF fillColor);
	//直线、圆、椭圆、正方形
	CShape(int shapeTYpe, CPoint ptOrigin, CPoint ptDestination);
	CShape(int shapeTYpe, CPoint ptOrigin, CPoint ptDestination , int lineStyle, int lineWidth=2,COLORREF lineColor=RGB(0,0,0), COLORREF fillColor = RGB(255, 255, 255));
	CShape(int shapeTYpe, int lineStyle, int lineWidth = 2, COLORREF lineColor = RGB(0, 0, 0), COLORREF fillColor = RGB(255, 255, 255));
public:
	void Draw(CDC* pDC);
	//编辑功能
	void MOVEGraph(int xoffset,int yoffset);//移动图形
	void Resize(float factor);//修改图案大小
	BOOL IsSelected(CPoint point);//是否被选中
	virtual void Serialize(CArchive& ar);
};


