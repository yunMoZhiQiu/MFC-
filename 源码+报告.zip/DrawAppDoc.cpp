﻿
// DrawAppDoc.cpp: CDrawAppDoc 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "DrawApp.h"
#endif

#include "DrawAppDoc.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDrawAppDoc

IMPLEMENT_DYNCREATE(CDrawAppDoc, CDocument)

BEGIN_MESSAGE_MAP(CDrawAppDoc, CDocument)
END_MESSAGE_MAP()


// CDrawAppDoc 构造/析构

CDrawAppDoc::CDrawAppDoc() noexcept
{
	// TODO: 在此添加一次性构造代码

}

CDrawAppDoc::~CDrawAppDoc()
{
}

/*
int GetShapeCount();//获取图形个数
	void RemoveShape(int index);//删除指定元素
	void RemoveAll();//删除所有
	void ChangeShapeColor(int index,COLORREF color);//修改图形颜色
	CShape* GetShape(int index);//获取对象，选中
	void AddShape(CShape *pShape);
	void MoveShape(int index, int xoffset, int yoffset);
	int GetSelectedShapeInsex(CPoint point);
*/
int CDrawAppDoc::GetShapeCount() {
	return m_shapeArray.GetSize();

}
void CDrawAppDoc::RemoveShape(int index){
	 m_shapeArray.RemoveAt(index);

}

void CDrawAppDoc::RemoveAll() {
	m_shapeArray.RemoveAll();

}

void CDrawAppDoc::ChangeShapeColor(int index, COLORREF color) {
	CShape* pShape = GetShape(index);
	pShape->SetLineColor(color);
	pShape->SetFillColor(color);

}
void CDrawAppDoc::MoveShape(int index, int xoffset, int yoffset) {
	CShape* pShape = GetShape(index);
	pShape->MOVEGraph(xoffset,yoffset);
}

CShape* CDrawAppDoc:: GetShape(int index) {
	return m_shapeArray.GetAt(index);
	
}

void CDrawAppDoc::AddShape(CShape* pShape) {
	m_shapeArray.Add(pShape);
}

int CDrawAppDoc::GetSelectedShapeInsex(CPoint point)
{
	return -1;//未选中的图形
}



BOOL CDrawAppDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: 在此添加重新初始化代码
	// (SDI 文档将重用该文档)

	return TRUE;
}




// CDrawAppDoc 序列化

void CDrawAppDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: 在此添加存储代码
	}
	else
	{
		// TODO: 在此添加加载代码
	}
	m_shapeArray.Serialize(ar);
}

#ifdef SHARED_HANDLERS

// 缩略图的支持
void CDrawAppDoc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// 修改此代码以绘制文档数据
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// 搜索处理程序的支持
void CDrawAppDoc::InitializeSearchContent()
{
	CString strSearchContent;
	// 从文档数据设置搜索内容。
	// 内容部分应由“;”分隔

	// 例如:     strSearchContent = _T("point;rectangle;circle;ole object;")；
	SetSearchContent(strSearchContent);
}

void CDrawAppDoc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = nullptr;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != nullptr)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CDrawAppDoc 诊断

#ifdef _DEBUG
void CDrawAppDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDrawAppDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CDrawAppDoc 命令
