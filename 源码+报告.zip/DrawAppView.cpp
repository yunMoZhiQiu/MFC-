﻿



//如果类向导报错，就需要手动添加BEGIN_MESSAGE_MAP中的相关配置，以及其他正常配置
// 首先是在View.h中添加afx_msg void OnDelete();
// 再在View.cpp的BEGIN_MESSAGE_MAP中添加ON_COMMAND(Delete, &CDrawAppView::OnDelete)
// 最后在cpp文件的最下面添加对应的方法并实现
// 
// 
// 
// 
// DrawAppView.cpp: CDrawAppView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "DrawApp.h"
#endif

#include "DrawAppDoc.h"
#include "DrawAppView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDrawAppView

IMPLEMENT_DYNCREATE(CDrawAppView, CView)

BEGIN_MESSAGE_MAP(CDrawAppView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_COMMAND(DRAW_Line, &CDrawAppView::OnDrawLine)
	ON_COMMAND(DRAW_Point, &CDrawAppView::OnDrawPoint)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
ON_WM_LBUTTONUP()
ON_WM_KEYDOWN()
ON_COMMAND(DRAW_Circle, &CDrawAppView::OnDrawCircle)
ON_COMMAND(DRAW_Ecilipse, &CDrawAppView::OnDrawEilipse)
ON_COMMAND(DRAW_Rectange, &CDrawAppView::OnDrawRectange)
ON_COMMAND(SuiShouHua, &CDrawAppView::OnDrawMULTLINE)
ON_COMMAND(ZheXian, &CDrawAppView::OnDRAWPOLYLINE)

ON_COMMAND(ID_FILE_SAVE, &CDrawAppView::OnFileSave)
ON_COMMAND(ID_FILE_OPEN, &CDrawAppView::OnFileOpen)

ON_WM_LBUTTONDBLCLK()

//按钮定义
//ON_WM_CREATE()
//ON_BN_CLICKED(IDB_BUTTON1,OnButton1Clicked)
//ON_BN_CLICKED(IDB_BUTTON2, OnButton2Clicked)
//ON_BN_CLICKED(IDB_BUTTON3, OnButton3Clicked)

ON_COMMAND(W1, &CDrawAppView::OnW1)
ON_COMMAND(W2, &CDrawAppView::OnW2)
ON_COMMAND(W3, &CDrawAppView::OnW3)
ON_COMMAND(W4, &CDrawAppView::OnW4)
ON_COMMAND(W5, &CDrawAppView::OnW5)
ON_COMMAND(W6, &CDrawAppView::OnW6)
ON_COMMAND(W7, &CDrawAppView::OnW7)
ON_COMMAND(W8, &CDrawAppView::OnW8)
ON_COMMAND(W9, &CDrawAppView::OnW9)
ON_COMMAND(W10, &CDrawAppView::OnW10)

ON_COMMAND(Delete, &CDrawAppView::OnDelete)
ON_COMMAND(Color, &CDrawAppView::OnColor)
//ON_COMMAND(Width, &CDrawAppView::OnWidth)
ON_COMMAND(Fill, &CDrawAppView::OnFill)
ON_COMMAND(Select, &CDrawAppView::OnSelect)
ON_COMMAND(Remove, &CDrawAppView::OnRemove)
//ON_COMMAND(Kuoda, &CDrawAppView::OnKuoda)
//ON_COMMAND(Suoxiao, &CDrawAppView::OnSuoxiao)
ON_COMMAND(ChangeColor, &CDrawAppView::OnChangecolor)
ON_COMMAND(ChangeFillColor, &CDrawAppView::OnChangefillcolor)
ON_COMMAND(ChangeSize, &CDrawAppView::OnChangesize)
ON_WM_MOUSEWHEEL()
ON_COMMAND(Cancel, &CDrawAppView::OnCancel)
END_MESSAGE_MAP()

// CDrawAppView 构造/析构

CDrawAppView::CDrawAppView() noexcept
{
	// TODO: 在此处添加构造代码

}

CDrawAppView::~CDrawAppView()
{
}

BOOL CDrawAppView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CDrawAppView 绘图

void CDrawAppView::OnDraw(CDC* pDC)
{
	CDrawAppDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 在此处为本机数据添加绘制代码
	for (int i = 0; i < pDoc->GetShapeCount(); i++)
	{
		pDoc->GetShape(i)->Draw(pDC);
	}
}


// CDrawAppView 打印

BOOL CDrawAppView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CDrawAppView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CDrawAppView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CDrawAppView 诊断

#ifdef _DEBUG
void CDrawAppView::AssertValid() const
{
	CView::AssertValid();
}

void CDrawAppView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDrawAppDoc* CDrawAppView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDrawAppDoc)));
	return (CDrawAppDoc*)m_pDocument;
}
#endif //_DEBUG


// CDrawAppView 消息处理程序
void CDrawAppView::OnLButtonDown(UINT nFlags, CPoint point)
{
	CDrawAppDoc* pDoc = GetDocument();
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	switch (m_shapType)
	{
	case 0:
		break;
	case 1:
	{		m_centrePoint = point;
	CShape* pShape = new CShape(1, m_centrePoint, 4);
	pDoc->AddShape(pShape);
	InvalidateRect(NULL, 1);
	break; }
	case 2:
	case 5:
	case 6:
	case 7:
		m_ptOrign = point;
		break;
	case 3:
	
	{
		pShapeN->m_pointArry.Add((point));
		break;
		
	}
	case 4:
	{
		cType = 4;
		break;
	}
	}
	CView::OnLButtonDown(nFlags, point);
}


//void CDrawAppView::OnMouseMove(UINT nFlags, CPoint point)
//{
//	CDrawAppDoc* pDoc = GetDocument();
	// TODO: 在此添加消息处理程序代码和/或调用默认值

//	CView::OnMouseMove(nFlags, point);
//}


void CDrawAppView::OnLButtonUp(UINT nFlags, CPoint point)
{
	CDrawAppDoc* pDoc = GetDocument();
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	switch (m_shapType)
	{
	case 0:
		break;
	case 1:
		break;
	case 2:
	case 5:
	case 6:
	case 7:
	{	
	m_ptDestination = point;
	CShape* pShape = new CShape(m_shapType, m_ptOrign, m_ptDestination, lineStyle, lineWidth, lineColor, fillColor);
	pDoc->AddShape(pShape);
	InvalidateRect(NULL, 1);
	break; 
	}
	case 4: {
			CShape* pShape = new CShape(pShapeN, lineWidth, lineColor, fillColor);
			pDoc->AddShape(pShape);
			InvalidateRect(NULL, 1);
			pShapeN->m_pointArry.RemoveAll();
			cType = 0;
			break;
	}

	}
	CView::OnLButtonUp(nFlags, point);
}

void CDrawAppView::OnDrawLine()
{
	isSelected = false;
	// TODO: 在此添加命令处理程序代码
	m_shapType = 2;
}


void CDrawAppView::OnDrawPoint()
{
	isSelected = false;
	// TODO: 在此添加命令处理程序代码
	m_shapType = 1;
}
void CDrawAppView::OnDrawCircle()
{
	isSelected = false;
	pShapeN->m_pointArry.RemoveAll();
	m_shapType = 5;
	// TODO: 在此添加命令处理程序代码
}


void CDrawAppView::OnDrawEilipse()
{
	isSelected = false;
	pShapeN->m_pointArry.RemoveAll();
	m_shapType = 7;
	// TODO: 在此添加命令处理程序代码
}


void CDrawAppView::OnDrawRectange()
{
	isSelected = false;
	pShapeN->m_pointArry.RemoveAll();
	m_shapType = 6;
	// TODO: 在此添加命令处理程序代码
}



void CDrawAppView::OnDrawMULTLINE()
{
	isSelected = false;
	m_shapType = 4;
	pShapeN->m_shapType = 4;
	//pShapeN->m_pointArry.RemoveAll();
	// TODO: 在此添加命令处理程序代码


}

//超级成功折线
void CDrawAppView::OnDRAWPOLYLINE()
{
	isSelected = false;
	m_shapType = 3;
	//pShapeN->m_pointArry.RemoveAll();
	pShapeN->m_shapType = 3;
	// TODO: 在此添加命令处理程序代码
}


void CDrawAppView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	CDrawAppDoc* pDoc = GetDocument();
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	switch (m_shapType)
	{
	case 3:

	{
		//该部分通过在view中设置一个公用pShapeN，在CShape中设置深拷贝的构造函数，来实现赋值，最后需要清空pShapeN
		CShape* pShape = new CShape(pShapeN,lineWidth,lineColor,fillColor);
		pDoc->AddShape(pShape);
		InvalidateRect(NULL, 1);
		pShapeN->m_pointArry.RemoveAll();
		break;
	}
	}
	//超简易的选中效果
	if (isSelected) {
		int n;
		int min=999;
		for (int i = 0; i < pDoc->m_shapeArray.GetSize(); i++)
		{
			if (pDoc->m_shapeArray.GetAt(i)->m_ptOrign.x !=0 && pDoc->m_shapeArray.GetAt(i)->m_ptOrign.y != 0)
			{
				double k, b;/*y=kx+b*/
				k = (pDoc->m_shapeArray.GetAt(i)->m_ptDestination.y - pDoc->m_shapeArray.GetAt(i)->m_ptOrign.y) / (pDoc->m_shapeArray.GetAt(i)->m_ptDestination.x - pDoc->m_shapeArray.GetAt(i)->m_ptOrign.x);
				b = pDoc->m_shapeArray.GetAt(i)->m_ptDestination.y - pDoc->m_shapeArray.GetAt(i)->m_ptDestination.x * k;

				double res = fabs(k * point.x - point.y + b) / sqrt(k * k + 1);
				if (res < min) {
					min = res;
					n = i;
			}
			}
		}
		pDoc->m_shapeArray.GetAt(n)->m_isSelected = true;
		pDoc->m_shapeArray.GetAt(n)->SetLineColor(RGB(255, 0, 0));
		InvalidateRect(NULL, 1);
		
	}

	CView::OnLButtonDblClk(nFlags, point);
}

//随手画
void CDrawAppView::OnMouseMove(UINT nFlags, CPoint point)
{
	CDrawAppDoc* pDoc = GetDocument();
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	switch (cType)
	{

	case 4: {
		TCHAR msg[100] = _T("");
		wsprintf(msg, _T("(%d,%d)"), point.x, point.y);
		pShapeN->m_pointArry.Add((point));
		//该部分通过在view中设置一个公用pShapeN，在CShape中设置深拷贝的构造函数，来实现赋值，最后需要清空pShapeN
		/*CShape* pShape = new CShape(pShapeN, lineWidth, lineColor, fillColor);
		pDoc->AddShape(pShape);
		InvalidateRect(NULL, 1);*/
		/*pShapeN->m_pointArry.RemoveAll();*/
		break;
	}
	}
	CView::OnMouseMove(nFlags, point);
}

void CDrawAppView::OnFileSave()
{
	Invalidate(FALSE);
	CClientDC dc(this);
	CRect rect;
	BOOL  showMsgTag;                  //是否要弹出”图像保存成功对话框" 
	GetClientRect(&rect);                  //获取画布大小
	HBITMAP hbitmap = CreateCompatibleBitmap(dc, rect.right - rect.left, rect.bottom - rect.top);
	//创建兼容位图
	HDC hdc = CreateCompatibleDC(dc);      //创建兼容DC，以便将图像保存为不同的格式
	HBITMAP hOldMap = (HBITMAP)SelectObject(hdc, hbitmap);
	//将位图选入DC，并保存返回值 
	BitBlt(hdc, 0, 0, rect.right - rect.left, rect.bottom - rect.top, dc, 0, 0, SRCCOPY);
	//将屏幕DC的图像复制到内存DC中
	CImage image;
	image.Attach(hbitmap);                //将位图转化为一般图像
	if (!saveTag)                          //如果图像是第一次被写入,则打开对话框
	{
		saveTag = TRUE;
		showMsgTag = TRUE;
		CString  strFilter = _T("位图文件(*.bmp)|*.bmp|JPEG 图像文件|*.jpg|GIF图像文件|*.gif|PNG图像文件|*.png|其他格式(*.*)|*.*||");
		CFileDialog dlg(FALSE, _T("bmp"), _T("iPaint1.bmp"), NULL, strFilter);
		if (dlg.DoModal() != IDOK)
			return;

		CString strFileName;          //如果用户没有指定文件扩展名，则为其添加一个
		CString strExtension;
		strFileName = dlg.m_ofn.lpstrFile;
		if (dlg.m_ofn.nFileExtension = 0)               //扩展名项目为0
		{
			switch (dlg.m_ofn.nFilterIndex) {
			case 1:
				strExtension = "bmp"; break;
			case 2:
				strExtension = "jpg"; break;
			case 3:
				strExtension = "gif"; break;
			case 4:
				strExtension = "png"; break;
			default:
				break;
			}
			strFileName = strFileName + "." + strExtension;
		}
		saveFilePath = strFileName;     //saveFilePath为视类中的全局变量,类型为CString
	}
	else {
		showMsgTag = FALSE;
	}
	//AfxMessageBox(saveFilePath);               //显示图像保存的全路径(包含文件名)
	HRESULT hResult = image.Save(saveFilePath);     //保存图像
	if (FAILED(hResult)) {
		MessageBox(_T("保存图像文件失败！"));
	}
	else {
		if (showMsgTag)
			MessageBox(_T("文件保存成功！"));
	}
	image.Detach();
	SelectObject(hdc, hOldMap);
}

void CDrawAppView::OnFileOpen()
{
	CString filter;
	filter = "位图文件(*.bmp)|*.bmp|其他格式(*.*)|*.*||";// 只能打开bmp
	/*filter = _T("位图文件(*.bmp)|*.bmp|JPEG 图像文件|*.jpg|GIF图像文件|*.gif|PNG图像文件|*.png|其他格式(*.*)|*.*||");*/
	CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, filter, NULL);
	//按下确定按钮 dlg.DoModal() 函数显示对话框
	if (dlg.DoModal() == IDOK)
	{
		BmpName = dlg.GetPathName();     //获取文件路径名   如D:\pic\abc.bmp
		EntName = dlg.GetFileExt();      //获取文件扩展名
		EntName.MakeLower();             //将文件扩展名转换为一个小写字符
		Invalidate();                    //调用该函数就会调用OnDraw重绘画图
	}


}

void CDrawAppView::ShowBitmap(CDC* pDC, CString BmpName)
{
	//定义bitmap指针 调用函数LoadImage装载位图
	HBITMAP m_hBitmap;
	m_hBitmap = (HBITMAP)LoadImage(NULL, BmpName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE | LR_CREATEDIBSECTION);

	if (m_bitmap.m_hObject)
	{
		m_bitmap.Detach();           //切断CWnd和窗口联系
	}
	m_bitmap.Attach(m_hBitmap);      //将句柄HBITMAP m_hBitmap与CBitmap m_bitmap关联

	//边界
	CRect rect;
	GetClientRect(&rect);

	//图片显示(x,y)起始坐标
	int m_showX = 0;
	int m_showY = 0;
	int m_nWindowWidth = rect.right - rect.left;   //计算客户区宽度
	int m_nWindowHeight = rect.bottom - rect.top;  //计算客户区高度

	//定义并创建一个内存设备环境DC
	CDC dcBmp;
	if (!dcBmp.CreateCompatibleDC(pDC))   //创建兼容性的DC
		return;

	BITMAP m_bmp;                          //临时bmp图片变量
	m_bitmap.GetBitmap(&m_bmp);            //将图片载入位图中

	CBitmap* pbmpOld = NULL;
	dcBmp.SelectObject(&m_bitmap);         //将位图选入临时内存设备环境

	//图片显示调用函数stretchBlt
	pDC->StretchBlt(0, 0, m_bmp.bmWidth, m_bmp.bmHeight, &dcBmp, 0, 0, m_bmp.bmWidth, m_bmp.bmHeight, SRCCOPY);

	dcBmp.SelectObject(pbmpOld);           //恢复临时DC的位图
	DeleteObject(&m_bitmap);               //删除内存中的位图
	dcBmp.DeleteDC();                      //删除CreateCompatibleDC得到的图片DC


}
//int CDrawAppView::OnCreate(LPCREATESTRUCT lpCreateStruct) {
//	if (CView::OnCreate(lpCreateStruct) == -1)
//		return -1;
//	m_Button1.Create(_T("颜色"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_ICON, CRect(10, 10, 100, 30), this, IDB_BUTTON1);
//	m_Button1.Create(_T("粗细"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_ICON, CRect(20, 20, 200, 60), this, IDB_BUTTON2);
//	m_Button1.Create(_T("填充"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | BS_ICON, CRect(40, 40, 400, 120), this, IDB_BUTTON3);
//	return 0;
//}
//void CDrawAppView::OnButton1Clicked() {
//
//
//}
//void CDrawAppView::OnButton2Clicked() {
//
//}
//void CDrawAppView::OnButton3Clicked() {
//
//}

void CDrawAppView::OnColor()
{
	// TODO: 在此添加命令处理程序代码
	CColorDialog dlg;
	if (dlg.DoModal() == IDOK)
	{
		COLORREF color = dlg.GetColor();
		lineColor = color;
		//lineColor = RGB(0,0,0);
	}

}

//失败
//void CDrawAppView::OnWidth()
//{
//	 TODO: 在此添加命令处理程序代码
//	lineWidth = 9;
//
//}
void CDrawAppView::OnW1()
{
//TODO: 在此添加命令处理程序代码
lineWidth = 1;
}
void CDrawAppView::OnW2()
{
	//TODO: 在此添加命令处理程序代码
	lineWidth = 2;
}
void CDrawAppView::OnW3()
{
	//TODO: 在此添加命令处理程序代码
	lineWidth = 3;
}
void CDrawAppView::OnW4()
{
	//TODO: 在此添加命令处理程序代码
	lineWidth = 4;
}
void CDrawAppView::OnW5()
{
	//TODO: 在此添加命令处理程序代码
	lineWidth =5;
}
void CDrawAppView::OnW6()
{
	//TODO: 在此添加命令处理程序代码
	lineWidth = 6;
}
void CDrawAppView::OnW7()
{
	//TODO: 在此添加命令处理程序代码
	lineWidth = 7;
}
void CDrawAppView::OnW8()
{
	//TODO: 在此添加命令处理程序代码
	lineWidth = 8;
}
void CDrawAppView::OnW9()
{
	//TODO: 在此添加命令处理程序代码
	lineWidth = 9;
}
void CDrawAppView::OnW10()
{
	//TODO: 在此添加命令处理程序代码
	lineWidth = 10;
}



void CDrawAppView::OnFill()
{
	// TODO: 在此添加命令处理程序代码
	CColorDialog dlg;
	if (dlg.DoModal() == IDOK)
	{
		COLORREF color = dlg.GetColor();
		fillColor = color;
		//lineColor = RGB(0,0,0);
	}
}



void CDrawAppView::OnSelect()
{
	// TODO: 在此添加命令处理程序代码
	m_shapType = 0;
	isSelected = true;
	/*MessageBox(_T("悬！"), _T("选择"));*/
}


void CDrawAppView::OnRemove()
{
	// TODO: 在此添加命令处理程序代码
	/*MessageBox(NULL, (LPCTSTR)"222", (LPCTSTR)"6666", IDOK);*/
	/*MessageBox(NULL, (LPCTSTR)"222", IDOK);*/
	if (isSelected)
		MessageBox(_T("请通过上下左右移动！"), _T("移动"));
	else
		MessageBox(_T("请选中要编辑对象！"), _T("错误"));
}


void CDrawAppView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{//该方式可以优化，对于选择了的图形，可以存到另外一个对象数组中，要移动时在这里遍历。
	CDrawAppDoc* pDoc = GetDocument();
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	for (int i = 0; i < pDoc->m_shapeArray.GetSize(); i++) {
		if (pDoc->m_shapeArray.GetAt(i)->m_isSelected==true)
		{
			switch (nChar)
			{
			case VK_UP:
				/*	MessageBox(_T("上！"), _T("移动"));*/
				pDoc->m_shapeArray.GetAt(i)->MOVEGraph(0, -10);
				Invalidate();
				break;
			case VK_DOWN:
				/*MessageBox(_T("下！"), _T("移动"));*/
				pDoc->m_shapeArray.GetAt(i)->MOVEGraph(0, 10);
				Invalidate();
				break;
			case VK_LEFT:
				/*MessageBox(_T("左！"), _T("移动"));*/
				pDoc->m_shapeArray.GetAt(i)->MOVEGraph(-10, 0);
				Invalidate();
				break;
			case VK_RIGHT:
				/*MessageBox(_T("右！"), _T("移动"));*/
				pDoc->m_shapeArray.GetAt(i)->MOVEGraph(10, 0);
				Invalidate();
				break;
			default:
				break;
			}
		}
	}
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}
void CDrawAppView::OnDelete()
{
	CDrawAppDoc* pDoc = GetDocument();
	// TODO: 在此添加命令处理程序代码
	
	for (int i = 0; i < pDoc->m_shapeArray.GetSize(); i++) {
		if (pDoc->m_shapeArray.GetAt(i)->m_isSelected == true)
		{
			pDoc->m_shapeArray.RemoveAt(i);
			Invalidate();
		}
	}
}


//void CDrawAppView::OnKuoda()
//{
	// TODO: 在此添加命令处理程序代码
//}


//void CDrawAppView::OnSuoxiao()
//{
	// TODO: 在此添加命令处理程序代码

//}


void CDrawAppView::OnChangecolor()
{
	CDrawAppDoc* pDoc = GetDocument();
	// TODO: 在此添加命令处理程序代码
	
	CColorDialog dlg;
	if (dlg.DoModal() == IDOK)
	{
		COLORREF color = dlg.GetColor();
		lineColor = color;
		for (int i = 0; i < pDoc->m_shapeArray.GetSize(); i++) {
			if (pDoc->m_shapeArray.GetAt(i)->m_isSelected == true)
			{
				pDoc->m_shapeArray.GetAt(i)->SetLineColor(color);
				Invalidate();
			}
		
		}
	}
}


void CDrawAppView::OnChangefillcolor()
{
	// TODO: 在此添加命令处理程序代码
	CDrawAppDoc* pDoc = GetDocument();
	

	CColorDialog dlg;
	if (dlg.DoModal() == IDOK)
	{
		COLORREF color = dlg.GetColor();
		fillColor = color;
		for (int i = 0; i < pDoc->m_shapeArray.GetSize(); i++) {
			if (pDoc->m_shapeArray.GetAt(i)->m_isSelected == true)
			{
				pDoc->m_shapeArray.GetAt(i)->SetFillColor(color);
				Invalidate();
			}
		
		}
	}
}


void CDrawAppView::OnChangesize()
{
	// TODO: 在此添加命令处理程序代码
	int n = 0;

	CDrawAppDoc* pDoc = GetDocument();
	for (int i = 0; i < pDoc->m_shapeArray.GetSize(); i++) {
		if (pDoc->m_shapeArray.GetAt(i)->m_isSelected == true)
		{
			n++;                  
		}
		if (n > 2)
		{
			MessageBox(_T("只能选择一个！"), _T("错误"));
		}
	}
	Invalidate();
}


BOOL CDrawAppView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	CDrawAppDoc* pDoc = GetDocument();
	for (int i = 0; i < pDoc->m_shapeArray.GetSize(); i++) {
		if (pDoc->m_shapeArray.GetAt(i)->m_isSelected == true)
		{
			if (zDelta>0)
			{
				pDoc->m_shapeArray.GetAt(i)->Resize(1.1);
				
			}
			else
			{
				pDoc->m_shapeArray.GetAt(i)->Resize(0.9);
			}
		}
	}
	Invalidate();

	return CView::OnMouseWheel(nFlags, zDelta, pt);
}


void CDrawAppView::OnCancel()
{
	// TODO: 在此添加命令处理程序代码
	CDrawAppDoc* pDoc = GetDocument();
	// TODO: 在此添加命令处理程序代码

	for (int i = 0; i < pDoc->m_shapeArray.GetSize(); i++) {
		if (pDoc->m_shapeArray.GetAt(i)->m_isSelected == true)
		{
			pDoc->m_shapeArray.GetAt(i)->m_isSelected =false;
			pDoc->m_shapeArray.GetAt(i)->SetLineColor(RGB(0, 0, 0));
			Invalidate();
		}
	}
}
