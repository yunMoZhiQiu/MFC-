﻿
// DrawAppView.h: CDrawAppView 类的接口
//
#include <windows.h>
#pragma once


class CDrawAppView : public CView
{
protected: // 仅从序列化创建
	CDrawAppView() noexcept;
	DECLARE_DYNCREATE(CDrawAppView)

// 特性
public:
	CDrawAppDoc* GetDocument() const;

// 操作
public:


	//保存位图
	bool saveTag = false;
	CString saveFilePath = _T("D:\\");

	//打开位图
	CString BmpName;                               //保存图像文件文件名
	CString EntName;                               //保存图像文件扩展名
	CBitmap m_bitmap;                              //创建位图对象

	int m_shapType=0;//0无效，1 点,2 直线,3 随手画,4随手画,5 圆,6 正方形,7 椭圆
	CPoint m_centrePoint;//中心点
	CPoint m_ptOrign, m_ptDestination;//起点和终点
	//折线 随手画 一系列的点、线
	//CTypedPtrArray<基类类型，参数类型>
	//CTypedPtrArray<CObArray, CPoint*> m_pointArry;//存储折线  DF_POLYLINBE  DF_MULTLINE
private:
	//绘图属性
		//绘图属性
	int m_pointSize;
	int m_lineStyle;
	int m_lineWidth;
	COLORREF m_lineColor;
	COLORREF m_fillColor;


// 重写
public:
	int cType = 0;
	//绘图属性
	int pointSize = 3;
	int lineStyle = 0;
	int lineWidth = 3;
	COLORREF lineColor = RGB(0, 0, 0);
	COLORREF fillColor = RGB(255, 255, 255);
	BOOL isSelected=false;//是否被选中
	//int shapType = 0;

	CButton m_Button1;
	CButton m_Button2;
	CButton m_Button3;
	virtual void OnDraw(CDC* pDC);  // 重写以绘制该视图
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	CShape* pShapeN = new CShape(m_shapType, lineStyle, lineWidth, lineColor, fillColor);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 实现
public:
	virtual ~CDrawAppView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 生成的消息映射函数
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnFileSave();
	afx_msg void OnFileOpen();
	void ShowBitmap(CDC* pDC, CString BmpName);

	afx_msg void OnDrawLine();
	afx_msg void OnDrawPoint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
//	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnDrawCircle();
	afx_msg void OnDrawEilipse();
	afx_msg void OnDrawRectange();
	afx_msg void OnDrawMULTLINE();
	afx_msg void OnDRAWPOLYLINE();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//afx_msg void OnButton1Clicked();
	//afx_msg void OnButton2Clicked();
	//afx_msg void OnButton3Clicked();
	afx_msg void OnDelete();
	afx_msg void OnColor();
//	afx_msg void OnWidth();
	afx_msg void OnFill();
	afx_msg void OnSelect();
	afx_msg void OnRemove();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
//	afx_msg void OnKuoda();
//	afx_msg void OnSuoxiao();
	afx_msg void OnChangecolor();
	afx_msg void OnChangefillcolor();
	afx_msg void OnChangesize();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnCancel();
	afx_msg void OnW1();
	afx_msg void OnW2();
	afx_msg void OnW3();
	afx_msg void OnW4();
	afx_msg void OnW5();
	afx_msg void OnW6();
	afx_msg void OnW7();
	afx_msg void OnW8();
	afx_msg void OnW9();
	afx_msg void OnW10();
};

#ifndef _DEBUG  // DrawAppView.cpp 中的调试版本
inline CDrawAppDoc* CDrawAppView::GetDocument() const
   { return reinterpret_cast<CDrawAppDoc*>(m_pDocument); }
#endif

