﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 DrawApp.rc 使用
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDB_BUTTON1                     101
#define IDB_BUTTON2                     102
#define IDB_BUTTON3                     103
#define IDR_MAINFRAME                   128
#define IDR_DrawAppTYPE                 130
#define ID_32771                        32771
#define ID_32772                        32772
#define DRAW_Point                      32773
#define DRAW_Line                       32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define DRAW_Circle                     32778
#define DRAW_Rectange                   32779
#define DRAW_Ecilipse                   32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ZheXian                         32783
#define SuiShouHua                      32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define Color                           32788
#define Width                           32789
#define Fill                            32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define Select                          32794
#define Delete                          32795
#define Remove                          32796
#define ID_32797                        32797
#define ID_32798                        32798
#define ID_32799                        32799
#define ChangeColor                     32800
#define Kuoda                           32801
#define Suoxiao                         32802
#define ID_32803                        32803
#define ChangeFillColor                 32804
#define ChangeSize                      32805
#define ID_32806                        32806
#define Cancel                          32807
#define W1                              32818
#define W2                              32819
#define W3                              32820
#define W4                              32821
#define W5                              32822
#define W6                              32823
#define W7                              32824
#define W8                              32825
#define W9                              32826
#define W10                             32827

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32828
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
